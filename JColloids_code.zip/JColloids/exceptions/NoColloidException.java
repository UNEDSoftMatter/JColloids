/*
 * Created on 09-dic-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package exceptions;

import ij.gui.HTMLDialog;
import interfaces.IMainInterface;

/**
 * Exception when no chain is found in the analysed image.  
 *
 */
public class NoColloidException extends NullPointerException implements IMainInterface
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Shows a HTMLDialog with a error message for the exception 
	 *
	 */
	public void showMessage()
	{
		new HTMLDialog(EXCP_ERROR, EXCP_NOCHAIN);
		
	}
	
}

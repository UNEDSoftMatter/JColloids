/*
 * Created on 09-dic-2004
 *
 *
 */
package exceptions;

import ij.gui.HTMLDialog;
import interfaces.IMainInterface;

/**
 * Exception for a directory empty path.   
 *
 */
public class EmptyDirectoryException extends NullPointerException implements IMainInterface
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Shows a HTMLDialog with a error message for the exception 
	 *
	 */
	public void showMessage()
	{
		new HTMLDialog(EXCP_ERROR, EXCP_NODIRECTORY);
	}
	
}

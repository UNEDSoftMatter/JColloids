package gui;

import interfaces.InputXML;
import interfaces.IMainInterface;

import java.awt.Color;


import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;
import javax.swing.UIManager;

import java.awt.Desktop;
import javax.swing.JTextPane;
import java.awt.Rectangle;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileSystemView;

import mains.*;

import com.l2fprod.common.swing.JDirectoryChooser;
import com.l2fprod.common.swing.plaf.LookAndFeelAddons;

import java.awt.Dimension;
import java.io.File;
import java.io.IOException;
import java.net.URL;


import java.awt.Font;
import javax.swing.JComboBox;


/**
 * This is the main class for the JChainAnalyser GUI. From here the main
 * programs are selected and run. Also, the input data and path directories
 * needed for the main programs are read from xml files and can be modified.
 *
 */
public class JColloidsGUI extends JFrame implements IMainInterface {

	private static final long serialVersionUID = 1L;
	private JPanel jContentPane = null;
	private JTabbedPane jTabbedPane = null;
	private JPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JTextPane jTextPane = null;
	private JLabel jLabel = null;
	private JButton jButton = null;
	private JLabel jLabel1 = null;
	private JTextField jTextField4 = null;
	private JLabel jLabel5 = null;
	private JButton jButton4 = null;
	private JLabel label_1 = null;
	
	private InputXML dirXML = new InputXML();
	
	private JButton jButton_help = null;
	private JTextField textField_1;
	private JTextField textField_2;
	
	private JComboBox jComboBoxErode = null;
	private JComboBox jComboBoxWater = null;
	private String	listDataDefaultTrue[] ={"true","false"};
	private String	listDataDefaultFalse[] ={"false","true"};
	private String[] listData = listDataDefaultTrue;

	
	/**
	 * This is the default constructor
	 */
	public JColloidsGUI() {
		super();
		initialize();
		
		
	}

	/**
	 * This method initializes this
	 * 
	 * @return void
	 */
	private void initialize() {
		this.setSize(451, 356);
		this.setMinimumSize(new Dimension(442, 343));
		this.setMaximumSize(new Dimension(442, 343));
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setPreferredSize(new Dimension(442, 343));
		this.setResizable(false);
		this.setContentPane(getJContentPane());
		this.setTitle("JColloids (JChainsAnalyser v2.0)");
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jLabel1 = new JLabel();
			jLabel1.setBounds(new Rectangle(107, 246, 248, 69));
			String nombrelogo =	"/"+
			"images"+
			"/"+
			//"JchainsAnalyser_peq.gif";
			"jcolloids.png";
			URL url = this.getClass().getResource(nombrelogo);
			jLabel1.setIcon(new ImageIcon(url));
			jContentPane = new JPanel();
			jContentPane.setLayout(null);
			jContentPane.add(getJTabbedPane(), null);
			jContentPane.add(jLabel1, null);
			
		
			
		}
		return jContentPane;
	}

	/**
	 * This method initializes jTabbedPane	
	 * 	
	 * @return javax.swing.JTabbedPane	
	 */
	private JTabbedPane getJTabbedPane() {
		if (jTabbedPane == null) {
			jTabbedPane = new JTabbedPane();
			jTabbedPane.setBounds(new Rectangle(0, 0, 440, 221));
			jTabbedPane.addTab(GUI_BEGIN, null, getJPanel1(), null);
			jTabbedPane.addTab(GUI_PARAMETERS, null, getJPanel2(), null);
			
		}
		return jTabbedPane;
	}

	/**
	 * This method initializes jPanel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel1() {
		if (jPanel == null) {
			
			jPanel = new JPanel();
			jPanel.setLayout(null);
			jPanel.setPreferredSize(new Dimension(10, 10));
			jPanel.setBackground(new Color(238, 238, 238));
			jPanel.add(getJTextPane(), null);
			
			jLabel = new JLabel();
			jLabel.setBounds(new Rectangle(100, 12, 285, 21));
			jLabel.setText(MSG_BEGIN_0);
			
			//Explanation
			jPanel.add(jLabel, null);
			//Run button
			jPanel.add(getJButton(), null);
			//Help button
			jPanel.add(getJButton_help(), null);
		}
		return jPanel;
	}

	/**
	 * This method initializes jPanel1	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanel2() {
		if (jPanel1 == null) {
			
			jPanel1 = new JPanel();
			jPanel1.setLayout(null);
			
			//LAbel Path
			jLabel5 = new JLabel();
			jLabel5.setText(GUI_PATH);
			jLabel5.setBounds(new Rectangle(12, 33, 97, 20));
			
			//JPanel path images
			jPanel1.add(getJTextFieldImages(), null);
			
			//Button browse images
			jPanel1.add(jLabel5, null);
			jPanel1.add(getJButtonBrowse(), null);
			
			//Label suffix
			label_1 = new JLabel();
			label_1.setText(GUI_SUFFIX);
			label_1.setBounds(new Rectangle(10, 15, 120, 21));
			label_1.setBounds(12, 65, 120, 21);
			jPanel1.add(label_1);
			
			//Suffix
			jPanel1.add(getJTextFieldSuffix(),null);
			
			JLabel label_2 = new JLabel();
			label_2.setText(GUI_INPUT_PARAMETERS);
			label_2.setBounds(new Rectangle(15, 13, 69, 21));
			label_2.setBounds(12, 98, 144, 19);
			jPanel1.add(label_2);
			
			
			//Factor
			JLabel lblFactor = new JLabel();
			lblFactor.setFont(new Font("Dialog", Font.BOLD, 10));
			lblFactor.setText(XML_INPUT_factorName);
			lblFactor.setBounds(new Rectangle(15, 13, 69, 21));
			lblFactor.setBounds(162, 97, 59, 19);
			jPanel1.add(lblFactor);
			
			jPanel1.add(getJTextFieldFactor(),null);
						
			//Erode
			JLabel lblErode = new JLabel();
			lblErode.setFont(new Font("Dialog", Font.BOLD, 10));
			lblErode.setText(XML_INPUT_erodeName);
			lblErode.setBounds(new Rectangle(15, 13, 69, 21));
			lblErode.setBounds(243, 97, 59, 19);
			jPanel1.add(lblErode);

			jPanel1.add(getJComboBoxErode(),null);
			
			//Watershed
			JLabel lblWatershed = new JLabel();
			lblWatershed.setFont(new Font("Dialog", Font.BOLD, 10));
			lblWatershed.setText(XML_INPUT_watershedName);
			lblWatershed.setBounds(new Rectangle(15, 13, 69, 21));
			lblWatershed.setBounds(331, 98, 92, 19);
			jPanel1.add(lblWatershed);
			
			jPanel1.add(getJComboBoxWater(),null);
			
		
			
			
		}
		return jPanel1;
	}

	/**


	/**
	 * This method initializes jTextPane	
	 * 	
	 * @return javax.swing.JTextPane	
	 */
	private JTextPane getJTextPane() {
		if (jTextPane == null) {
			jTextPane = new JTextPane();
			jTextPane.setBounds(new Rectangle(23, 45, 386, 67));
			jTextPane.setEditable(false);
			jTextPane.setForeground(Color.black);
			jTextPane.setText(MSG_BEGIN);
			jTextPane.setBackground(new Color(238,238,238));
			jTextPane.setToolTipText("");
			jTextPane.setContentType("text/plain");
		}
		return jTextPane;
	}

	/**
	 * This method initializes jButton	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton() {
		if (jButton == null) {
			jButton = new JButton();
			jButton.setText(LABEL_RUN);
			jButton.setFont(new Font("Dialog", Font.BOLD, 10));
			jButton.setBounds(new Rectangle(160, 124, 104, 27));
			jButton.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
			        	new Console(new PrincipalCommand());

				}
			});
		}
		return jButton;
	}

	/**


	/**
	 * Path for the images
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldImages() {
		if (jTextField4 == null) {
			jTextField4 = new JTextField();
			jTextField4.setBounds(new Rectangle(162, 34, 173, 19));
			jTextField4.setText(dirXML.getsPath());
			jTextField4.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if ( e.getSource() == jTextField4)
					{
						jTextField4.setBackground(Color.WHITE);
						dirXML.writeTextToXML(jTextField4.getText(), XML_INPUT_directoryName);
						
					}
				}
			});

			jTextField4.getDocument().addDocumentListener 
			(new DocumentListener()	{
				public void changedUpdate(DocumentEvent de)
				{
					try
					{jTextField4.setBackground(Color.YELLOW); }
					catch (Exception e){}
			
				}
				public void removeUpdate(DocumentEvent de)
				{ changedUpdate (de); }
				public void insertUpdate(DocumentEvent de)
				{ changedUpdate (de); }
			
			});
		}
		return jTextField4;
	}


	/**
	 * Button for Browse images	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonBrowse() {
		if (jButton4 == null) {
			jButton4 = new JButton();
			jButton4.setText(LABEL_BROWSE);
			jButton4.setBounds(new Rectangle(347, 35, 76, 19));
			jButton4.setFont(new Font("Dialog", Font.BOLD, 10));
			jButton4.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					String path = giveDirectory(jTextField4.getText());
					jTextField4.setText(path);
				}
			});

		}
		return jButton4;
	}

	
	/**
	 * Value suffix
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldSuffix() {
		if (textField_1 == null) {
						
			textField_1 = new JTextField();
			textField_1.setText(dirXML.getsSuffix());
			textField_1.setBounds(new Rectangle(150, 19, 70, 15));
			textField_1.setBounds(162, 66, 173, 19);

			textField_1.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if ( e.getSource() == textField_1)
					{
						textField_1.setBackground(Color.WHITE);
						dirXML.writeTextToXML(textField_1.getText(), XML_INPUT_suffixName);
						
					}
				}
			});

			textField_1.getDocument().addDocumentListener 
			(new DocumentListener()	{
				public void changedUpdate(DocumentEvent de)
				{
					try
					{textField_1.setBackground(Color.YELLOW); }
					catch (Exception e){}
			
				}
				public void removeUpdate(DocumentEvent de)
				{ changedUpdate (de); }
				public void insertUpdate(DocumentEvent de)
				{ changedUpdate (de); }
			
			});
		}
		return textField_1;
	}


	/**
	 * Path for the images
	 * 	
	 * @return javax.swing.JTextField	
	 */
	private JTextField getJTextFieldFactor() {
		if (textField_2 == null) {
			
			
			textField_2 = new JTextField();
			textField_2.setText(dirXML.readStringFromFile(XML_INPUT_factorName));
			textField_2.setBounds(new Rectangle(138, 15, 40, 15));
			textField_2.setBounds(162, 127, 59, 19);
			
			textField_2.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					if ( e.getSource() == textField_2)
					{
						textField_2.setBackground(Color.WHITE);
						dirXML.writeTextToXML(textField_2.getText(), XML_INPUT_factorName);
						
					}
				}
			});

			textField_2.getDocument().addDocumentListener 
			(new DocumentListener()	{
				public void changedUpdate(DocumentEvent de)
				{
					try
					{textField_2.setBackground(Color.YELLOW); }
					catch (Exception e){}
			
				}
				public void removeUpdate(DocumentEvent de)
				{ changedUpdate (de); }
				public void insertUpdate(DocumentEvent de)
				{ changedUpdate (de); }
			
			});
		}
		return textField_2;
	}

	 /**
	 * This method initializes jComboBoxErode	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxErode() {
		
		
		if (jComboBoxErode == null) {
			boolean bool = dirXML.readBooleanFromFile(XML_INPUT_erodeName);
			
			if (bool==true)
				listData = listDataDefaultTrue;
			else if (bool==false)
				listData = listDataDefaultFalse;
			
			jComboBoxErode = new JComboBox(listData);
			jComboBoxErode.setBounds(new Rectangle(282, 13, 64, 18));
			jComboBoxErode.setBounds(243, 127, 76, 18);		
			
			jComboBoxErode.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JComboBox cb = (JComboBox)e.getSource();
					dirXML.writeTextToXML((String)cb.getSelectedItem(), XML_INPUT_erodeName);
					 
				}
			});
		}

		return jComboBoxErode;
	 }

	
	 /**
	 * This method initializes jComboBoxWater	
	 * 	
	 * @return javax.swing.JComboBox	
	 */
	private JComboBox getJComboBoxWater() {
		
		
		if (jComboBoxWater == null) {
			boolean bool = dirXML.readBooleanFromFile(XML_INPUT_watershedName);
			
			if (bool==true)
				listData = listDataDefaultTrue;
			else if (bool==false)
				listData = listDataDefaultFalse;
			
			jComboBoxWater = new JComboBox(listData);
			jComboBoxWater.setBounds(new Rectangle(349, 13, 64, 18));
			jComboBoxWater.setBounds(331, 127, 76, 18);
						
			jComboBoxWater.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
					JComboBox cb = (JComboBox)e.getSource();
					dirXML.writeTextToXML((String)cb.getSelectedItem(), XML_INPUT_watershedName);
					 
				}
			});
		}

		return jComboBoxWater;
	 }

	
	/**
	 * Displays JDirectoryChooser for selecting input/output paths
	 * @param String path_0
	 * @return String
	 */
	public String giveDirectory(String path_0) {
		
		String path="";
		
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
			LookAndFeelAddons.setAddon(LookAndFeelAddons
					.getBestMatchAddonClassName());
		}
		catch(Exception e) {
		}
		 
		File f = FileSystemView.getFileSystemView().getHomeDirectory();
		JDirectoryChooser chooser = new JDirectoryChooser("Select Directory");
		chooser.setVisible(true);
		chooser.setCurrentDirectory(f);
		//chooser.showDialog(null, "Select");
	    // Show the dialog; wait until dialog is closed
		 
		int result = chooser.showOpenDialog(null);
	    // Determine which button was clicked to close the dialog
	    switch (result) {
	      case JFileChooser.APPROVE_OPTION:
	        // Approve (Open or Save) was clicked
	    	  File dir = chooser.getSelectedFile(); 
	    	  path =  dir.getAbsolutePath(); 
	        break;
	      case JFileChooser.CANCEL_OPTION:
	        // Cancel or the close-dialog icon was clicked
	    	  path = path_0;
	        break;
	      case JFileChooser.ERROR_OPTION:
	    	  path = path_0;
	        // The selection process did not complete successfully
	        break;
	    }
			
		return path;
	}




	/**
	 * This method initializes jButton_help	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButton_help() {
		if (jButton_help == null) {
			jButton_help = new JButton();
			jButton_help.setBounds(new Rectangle(393, 152, 30, 30));
			String nombrelogo =	"/"+
			"images"+
			"/"+
			"help.png";
			URL url = this.getClass().getResource(nombrelogo);
			jButton_help.setIcon(new ImageIcon(url));
			jButton_help.addActionListener(new java.awt.event.ActionListener() {
				public void actionPerformed(java.awt.event.ActionEvent e) {
						
						String shelp = HELP_FILE;
						 Desktop desktop = null;
						    // Before more Desktop API is used, first check 
						    // whether the API is supported by this particular 
						    // virtual machine (VM) on this particular host.
						  if (Desktop.isDesktopSupported()) {
						        desktop = Desktop.getDesktop();
						        try {
									
						        	desktop.open(new File(shelp));
									
								} catch (IOException e1) {
									e1.printStackTrace();
									
								}
							
						  }

				

				}
			});
		}
		return jButton_help;
	}


	/**
	 * Returns the objects corresponding to the xml file
	 * @return DirectoriesXML
	 */

	public InputXML getDirXML() {
		return dirXML;
	}
}  //  @jve:decl-index=0:visual-constraint="10,10"

package interfaces;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;
import org.jdom2.output.XMLOutputter;

/**
 * Reads/Writes the <i>directories.xml</i> file. 
 *
 */
public class InputXML implements IMainInterface{

	private String xmlfile = XML_INPUT;
	private String sPath = "";
	private String sSuffix = "";
	private double dFactor = 0.5;
	private boolean bErode = true;
	private boolean bWater = true;


	
	public InputXML(	String sPath,
						String sSuffix,
						double dFactor,
						boolean bErode,
						boolean bWater)
	{
		this.sPath = sPath;
		this.sSuffix = sSuffix;
		this.dFactor = dFactor;
		this.bErode = bErode;
		this.bWater = bWater;
	}

	public String getsPath() {
		return sPath;
	}

	public void setsPath(String sPath) {
		this.sPath = sPath;
	}

	public String getsSuffix() {
		return sSuffix;
	}

	public void setsSuffix(String sSuffix) {
		this.sSuffix = sSuffix;
	}

	public double getdFactor() {
		return dFactor;
	}

	public void setdFactor(double dFactor) {
		this.dFactor = dFactor;
	}

	public boolean isbErode() {
		return bErode;
	}

	public void setbErode(boolean bErode) {
		this.bErode = bErode;
	}

	public boolean isbWater() {
		return bWater;
	}

	public void setbWater(boolean bWater) {
		this.bWater = bWater;
	}

	public InputXML()
	{
		
		this.sPath = this.readStringFromFile(XML_INPUT_directoryName);
		this.sSuffix = this.readStringFromFile(XML_INPUT_suffixName);
		this.dFactor = this.readDoubleFromFile(XML_INPUT_factorName);
		this.bErode = this.readBooleanFromFile(XML_INPUT_erodeName);
		this.bWater = this.readBooleanFromFile(XML_INPUT_watershedName);

		
		
	}
	
	
	public String readStringFromFile(String field)
	{
		
		String paths = new String();
        SAXBuilder builder=new SAXBuilder(); 
        File xml = new File(this.xmlfile);
        
    	Document doc = null;

		try {
		    	doc = (Document) builder.build(xml);

		    	Element raiz=doc.getRootElement();   
		        Element e = raiz.getChild(field);
		        paths =  e.getValue(); 
		        
		        
		        
			} catch (JDOMException jdom) {
				System.out.println( jdom.getMessage() );
			} catch (IOException e1) {
				System.out.println( e1.getMessage() );
		}
		return paths;
	}
	
	public double readDoubleFromFile( String field)
	{
		
		double dValue = 0.0;
        SAXBuilder builder=new SAXBuilder(); 
        File xml = new File(xmlfile);
        
    	Document doc = null;

		try {
		    	doc = (Document) builder.build(xml);

		    	Element raiz=doc.getRootElement();   
		        Element e = raiz.getChild(field);
		        dValue = new Double(Double.parseDouble(e.getValue())).doubleValue();
		        
		        
			} catch (JDOMException jdom) {
				System.out.println( jdom.getMessage() );
			} catch (IOException e1) {
				System.out.println( e1.getMessage() );
		}
		return dValue;
	}
	
	public boolean readBooleanFromFile(String field)
	{
		
		boolean bValue = true;
        SAXBuilder builder=new SAXBuilder(); 
        File xml = new File(xmlfile);
        
    	Document doc = null;

		try {
		    	doc = (Document) builder.build(xml);

		    	Element raiz=doc.getRootElement();   
		        Element e = raiz.getChild(field);
		        bValue = new Boolean(Boolean.parseBoolean(e.getValue())).booleanValue();
		        
		        
			} catch (JDOMException jdom) {
				System.out.println( jdom.getMessage() );
			} catch (IOException e1) {
				System.out.println( e1.getMessage() );
		}
		return bValue;
	}
	
	

	public void writeTextToXML(String textValue, String field)
	{
		SAXBuilder builder=new SAXBuilder();
		File xml = new File(xmlfile);
		Document doc = null;
		
		try {
				doc = (Document) builder.build(xml);
		        Element raiz=doc.getRootElement();   
		        Element e = raiz.getChild(field);
		        e.setText(textValue);
		        
 
				XMLOutputter outputter = new XMLOutputter();
				FileWriter writer = new FileWriter(xmlfile);
				outputter.output(doc, writer);
				writer.close();

		} catch (JDOMException jdom) {
			System.out.println( jdom.getMessage() );
		} catch (IOException e1) {
			System.out.println( e1.getMessage() );
		}
	}
	
	
}

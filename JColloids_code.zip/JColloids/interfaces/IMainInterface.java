/*
 * Created on 07-dic-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package interfaces;

import java.io.File;

/**
 * 
 * Contains messages, labels, files names used by JChainsAnalyser.
 */
public interface IMainInterface 
{
	public static String JCHAINS_VERSION = "JChainsAnalyser v2.0";
	
	public static String GUI_BEGIN = "Begin";
	public static String GUI_PARAMETERS = "Parameters";
	public static String GUI_PATH = "images path: ";
	public static String GUI_SUFFIX = "image file suffix: ";
	public static String GUI_INPUT_PARAMETERS = "Input parameters: ";
	
	public static String DIR_EMPTY = "(Empty)";
	 
	public static String LABEL_NEW = "new";
	public static String HELP_FILE = "help.pdf";
	
	public static String OUTPUT_analysed = "analysed";
	public static String OUTPUT_statistics = "statistics";
	public static String OUTPUT_binaryName = "binary";
	
	public static String XML_INPUT = "input.xml";
	public static String XML_INPUT_rootName = "Parameters";
	public static String XML_INPUT_suffixName = "suffix";
	public static String XML_INPUT_directoryName = "images";
	public static String XML_INPUT_factorName = "factor";
	public static String XML_INPUT_erodeName = "erode";
	public static String XML_INPUT_watershedName = "watershed";
	public static String TXT_REPORT = "report";
	
	public static String dataName = "data";
	
	public static String LABEL_TERMAFTERNAME = "image file suffix";
	public static String LABEL_OK = "Ok";
	public static String LABEL_BROWSE = "Browse";
	public static String LABEL_RUN = "RUN";
	public static String LABEL_HELP = "Help";
	public static String LABEL_Save = "Save";
	
	public static String MSG_BEGIN_0 = "Thank you for using JColloids.";
	public static String MSG_BEGIN = "Please be sure you have selected the right paths" +
			" and data configuration in the" +
			" fields contained in the tabs." +
			" Then, press the button RUN.";
	public static String MSG_RUNNING = "RUNNING";
	public static String MSG_CLEAR_CONSOLE = "Clear Console";
	public static String MSG_STOPALL = "STOP ALL";
	public static String MSG_ERROR = "ERROR";
	public static String MSG_FREEMEMORY_CURRENT = "Current Free Memory: ";
	public static String MSG_FREEMEMORY_FREEING = "Freeing Up Memory: ";
	public static String MSG_READING_FROM = "Reading from ";
	public static String MSG_WRITING_IN = "Writing in ";
	public static String MSG_END_PCA = "-----All processes ended-----";
	public static String MSG_BEGIN_FILTERING = "-----Begin filtering images process----- ";
	public static String MSG_END_FILTERING = "-----Filtering images ended-----";	
	public static String MSG_BEGIN_ANALYSE = "-----Begin analysing images process----- ";
	public static String MSG_END_ANALYSE = "-----Analysing images ended-----";		
	public static String MSG_READING_FILE_NAMES = "Reading file names...";
	public static String MSG_INITIAL_TIME = "Initial time: ";
	public static String MSG_NUMBER_FILES = "Number of files: ";
	public static String MSG_COPYING_FILES = "Copying files to the directory...";
	public static String MSG_REPORT_SAVED = "-----Analysis Report Saved-----";
	public static String MSG_BEGIN_PRINCIPAL = "-----Filtering and Analysing Beggining-----";
	public static String MSG_COMPLETED_PERCENT = "Completed in a ";
	public static String MSG_END_PRINCIPAL = "-----Filtering and Analysing Ended-----";
	public static String MSG_STATISTICS_SAVED = "-----Statistics Saved-----";
	
	public static String RPT_CONTRAST_VALUES = "Contrast Values: ";
	public static String RPT_AUTOCONTRAST = "Autocontrast";
	public static String RPT_FILTER_VALUES = "Filter Values: ";
	public static String RPT_AUTOFILTER = "Autofiltered";
	public static String RPT_AUTOFILTER_PARAMETER = "Autofilter parameter: ";
	public static String RPT_ROLLINGBALL = "Rolling Ball: ";
	public static String RPT_WATERSHED = "Watershed: ";
	public static String RPT_ERODE = "Erode: ";
	
	//EXCEPTION MESSAGES
	public static String EXCP_ERROR = "ERROR";
	public static String EXCP_NOCHAIN = "No Chain Detected.";
	public static String EXCP_NODIRECTORY = "Directory Path Not Found.";
	public static String EXCP_MYIOEXCEPTION = "There is a problem accessing a file.";
	public static String EXCP_MYPARSEEXCEPTION = "Problem converting data format.";
	
	public static String ENC_TIME = "Time";
	public static String ENC_AREA = "Area";
	public static String ENC_CIRC = "Circularity";
	public static String ENC_CMX = "CMX";
	public static String ENC_CMY = "CMY";
	public static String ENC_LABEL = "Label";

	
	static final String DIR_SEPARATOR = File.separator;
	
}

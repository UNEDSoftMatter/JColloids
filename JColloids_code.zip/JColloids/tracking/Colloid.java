/*
 * Created on 16-dic-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package tracking;


import java.util.ArrayList;
import ij.gui.PolygonRoi;
import interfaces.IMainInterface;
import java.awt.geom.Point2D;

/**
 * This object represents the chain, the set of aggregated particles. 
 * Its attributes are usual morphological and geometrical 
 * properties like center of mass, circularity, perimeter, etc. 
 *
 */
public class Colloid implements IMainInterface
{
	private float	CMx;
	private float	CMy;
	private float circularity;
	private float perimeter;
	private float[] contourX;
	private float[] contourY;
	private float area;
	private String columnHeadings;
	private double time;
	private int numberChain;
	
	private float numberParticles;
	private float particleRatio;
	private PolygonRoi polyRoi;
	

	private double[] d;
	
	ArrayList proyectedPoints = new ArrayList();
	
	private StringBuffer strContour = new StringBuffer();
	private StringBuffer strLineProyection = new StringBuffer();
	
	
	public Colloid() {}
	
	public Colloid(Integer[] contx, Integer[] conty, double conversion)
	{
		
		this.contourX = calibrateContour(contx, conversion);
		this.contourY = calibrateContour(conty, conversion);
			
	}

	
	public static int max(double[] t) {
	    int ind = 0;
		double maximum = t[0];
	    for (int i=1; i<t.length; i++) {
	        if (t[i] > maximum) 
	        {
	            maximum = t[i];
	            ind = i; // new maximum
	        }
	    }
	    return ind;
	}//end method max
	
	
	public static int min(double[] t) {
	    int ind = 0;
		double minimum = t[0];
	    for (int i=1; i<t.length; i++) {
	        if (t[i] < minimum) 
	        {
	        	minimum = t[i];
	            ind = i; // new minumum
	        }
	    }
	    return ind;
	}//end method min
	
	public static int max(float[] t) {
	    int ind = 0;
		double maximum = t[0];
	    for (int i=1; i<t.length; i++) {
	        if (t[i] > maximum) 
	        {
	            maximum = t[i];
	            ind = i; // new maximum
	        }
	    }
	    return ind;
	}//end method max
	
	
	public static int min(float[] t) {
	    int ind = 0;
		double minimum = t[0];
	    for (int i=1; i<t.length; i++) {
	        if (t[i] < minimum) 
	        {
	        	minimum = t[i];
	            ind = i; // new minumum
	        }
	    }
	    return ind;
	}//end method min
	
	public static int minx(Point2D.Double[] t) {
	    int ind = 0;
		double minimum = t[0].x;
	    for (int i=1; i<t.length; i++) {
	    	if (t[i].x < minimum) 
	        {
	        	minimum = t[i].x;
	            ind = i; // new minumum
	        }
	    }
	    return ind;
	}//end method min
	
	public static int miny(Point2D.Double[] t) {
	    int ind = 0;
		double minimum = t[0].y;
	    for (int i=1; i<t.length; i++) {
	        if (t[i].y < minimum) 
	        {
	        	minimum = t[i].y;
	            ind = i; // new minumum
	        }
	    }
	    return ind;
	}//end method min	
	
	public static int maxx(Point2D.Double[] t) {
	    int ind = 0;
		double maximum = t[0].x;
	    for (int i=1; i<t.length; i++) {
	        if (t[i].x > maximum) 
	        {
	            maximum = t[i].x;
	            ind = i; // new maximum
	        }
	    }
	    return ind;
	}//end method max
	
	public static int maxy(Point2D.Double[] t) {
	    int ind = 0;
		double maximum = t[0].y;
	    for (int i=1; i<t.length; i++) {
	        if (t[i].y > maximum) 
	        {
	            maximum = t[i].y;
	            ind = i; // new maximum
	        }
	    }
	    return ind;
	}//end method max
		

	private float[] calibrateContour(Integer[] integ1, double conversion)
	{
		float[] integ2 = new float[integ1.length];
		for (int i=0; i<integ1.length; i++)
		{
			integ2[i] = (float)(conversion*(integ1[i].doubleValue()));
		}
		return integ2;
		
	}
	
	
	
	public float areaParticle(double radio)
	{
		
		return (float)(Math.PI*radio*radio); 
		
	}
	

	
	
	public double meanArrayFromN1ToN2(double[] p, int N1, int N2) {
	    
		double sum = 0;  // sum of all the elements
	    for (int i=N1; i<N2; i++) {
	        sum += p[i];
	    }
	    return sum / Math.abs(N1-N2);
	}//end method mean
	

	
	
	public void sort (double[] arr, double[] arry)
	{
		sort (arr, arry, 0, arr.length-1);
	}
	
	public void sort (double[] arr, double[] arry, int begin, int end)
	{
		if (end > begin)
		{
			int low = begin;
			int high = end;
			double middle = arr[(begin + end) / 2];
			while (low <= high)
			{
				while (low < end && arr[low] < middle)
				{
					low++;
				}
				while (high > begin && arr[high] > middle)
				{
					high--;	
				}
				if (low <= high)
				{
					double temp = arr[low]; double tempy = arry[low];
					arr[low] = arr[high]; arry[low] = arry[high];
					arr[high] = temp; arry[high] = tempy;
					low++;
					high--;	
				}
			}
			if (begin < high)
			{
				sort (arr, arry, begin, high);	
			}
			if (low < end)
			{
				sort (arr, arry, low, end);
			}
		}
	}



	
	public double meanArrays(double[] array)
	{
		int N = array.length;
		double sumaarray = 0;
		for (int i=0; i<array.length; i++)
			sumaarray = sumaarray + array[i];
		return (double)sumaarray/N;
	
	}
	

	
	public void putNumberOfParticles()
	{
		this.numberParticles = (float)(this.area / areaParticle(this.particleRatio));
		

	}
	

	
	public void putCircularity() 
	{
		float circ = (float)0.0;
		if (!(this.perimeter<0.0001))
			circ = (float) (4.0*Math.PI*(this.area/(this.perimeter*this.perimeter)));
		if (circ > 1)
			circ = (float)1.0;
		this.circularity = circ;
	}

	public float getCMx() {
		return CMx;
	}

	public void setCMx(float cMx) {
		CMx = cMx;
	}

	public float getCMy() {
		return CMy;
	}

	public void setCMy(float cMy) {
		CMy = cMy;
	}

	public float getCircularity() {
		return circularity;
	}

	public void setCircularity(float circularity) {
		this.circularity = circularity;
	}

	public float getPerimeter() {
		return perimeter;
	}

	public void setPerimeter(float perimeter) {
		this.perimeter = perimeter;
	}

	public float[] getContourX() {
		return contourX;
	}

	public void setContourX(float[] contourX) {
		this.contourX = contourX;
	}

	public float[] getContourY() {
		return contourY;
	}

	public void setContourY(float[] contourY) {
		this.contourY = contourY;
	}

	public float getArea() {
		return area;
	}

	public void setArea(float area) {
		this.area = area;
	}

	public String getColumnHeadings() {
		return columnHeadings;
	}

	public void setColumnHeadings(String columnHeadings) {
		this.columnHeadings = columnHeadings;
	}

	public double getTime() {
		return time;
	}

	public void setTime(double time) {
		this.time = time;
	}
	



}

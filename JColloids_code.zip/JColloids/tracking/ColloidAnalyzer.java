/*
 * Created on 10-dic-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package tracking;


import java.awt.Rectangle;
import java.util.ArrayList;

import ij.IJ;
import ij.ImagePlus;

import ij.gui.PolygonRoi;
import ij.gui.Roi;

import ij.measure.ResultsTable;
import ij.process.ImageProcessor;
import ij.process.ImageStatistics;


/**
 * 
 * Extends <i>ParticleAnalyzer_JChains</i> instead of the ImageJ's
 * <i>ParticleAnalyzer</i> because of the need of accesing to the
 * ImageProcessor drawIP inside <i>ParticleAnalyzer</i>.
 * 
 * It modifies some of the methods for drawing particles and storaging
 * the data of the contours. 
 *
 */
public class ColloidAnalyzer extends ParticleAnalyzer_JColloids{
	
	public static final int NOTHING=0,OUTLINES=1,MASKS=2,ELLIPSES=3,OUTLINES_WITHOUT_TEXT=4;
	
	private String titleImageFinal="";
	private ImagePlus imageFinal;
	//private int tipoFiltro=ChainAnalyzer.MASKS;
	private int filterType=ColloidAnalyzer.OUTLINES;
	
	//informacion para la cadenas
	private ResultsTable rtStats;
	private ImageStatistics imageStats;
	private Roi roiStats;
	private PolygonRoi polyRoi;
	
	//Almacena los arrays que contienen los contornos 
	//de cada cadena
	private ArrayList listContourX = new ArrayList();
	private ArrayList listContourY = new ArrayList();
	
	//Para ver cuantas cadenas hay
	private int count = 0;
	
	/**
	 * @param arg0
	 * @param arg1
	 * @param arg2
	 * @param arg3
	 * @param arg4
	 */
	
	public ColloidAnalyzer(int arg0, int arg1, ResultsTable arg2,
			double arg3, double arg4) {
		super(arg0, arg1, arg2, arg3, arg4);
		// TODO Auto-generated constructor stub
	}
	
	public ColloidAnalyzer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public ColloidAnalyzer(	int arg0,int arg1, 
							ResultsTable arg2,
							double arg3, 
							double arg4, 
							String titulo) 
	{
		super(arg0, arg1, arg2, arg3, arg4);
		this.titleImageFinal = titulo;
		
	}

	
	
	public ColloidAnalyzer(	int arg0, 
									int arg1, 
									ResultsTable arg2,
									double arg3, 
									double arg4, 
									String titulo,
									int tipoFiltro) 
	{
		super(arg0, arg1, arg2, arg3, arg4);
		this.titleImageFinal = titulo;
		this.filterType = tipoFiltro;
		
		
	
	}

	/**
	 * With this method we save the results of each particle in the
	 *  ResultTable */
	protected void saveResults(ImageStatistics stats, Roi roi) 
	{
		int xStartC = rt.getColumnIndex("xStartC");
		int yStartC = rt.getColumnIndex("yStartC");
		
		analyzer.saveResults(stats, roi);
		
			
		if (recordStarts) {
			int coordinates = ((PolygonRoi)roi).getNCoordinates();
			Rectangle r = roi.getBounds();
			int x = r.x+((PolygonRoi)roi).getXCoordinates()[coordinates-1];
			int y = r.y+((PolygonRoi)roi).getYCoordinates()[coordinates-1];
			rt.addValue(xStartC, x);
			rt.addValue(yStartC, y);
		}
		if (showResults)
			analyzer.displayResults();
		
		this.rtStats = rt;
		this.roiStats = roi;
		this.imageStats = stats;
	}
	
	/** Performs particle analysis on the specified image. Returns
	*	false if there is an error. 
	*	Here we use the inhereted ImageProcessor drawIP from 
	*	ParticleAnalyzer_JChains
	*/
	public boolean analyse(ImagePlus imp, ImageProcessor ip) 
	{
		boolean dev = analyze(imp, ip);
		
		//Here we use the inhereted ImageProcessor drawIP
		this.imageFinal=new ImagePlus(this.titleImageFinal, drawIP.createImage());
		
		/**
		 * For an adequate working of the method it is needed to use the inhereted
		 * drawIP. If we use something like:
		 * this.imagenFinal=new ImagePlus(this.tituloImagenFinal, ip.createImage());
		 * the images are shown and the chains are not drawed as contours. 
		 *
		 */
		
		return dev;
	}

	
	/** Draws a selected particle in a separate image.  This is
	another method subclasses may want to override. */
	protected void drawParticle(	ImageProcessor drawIP, 
									Roi roi,
									ImageStatistics stats, 
									ImageProcessor mask) 
	{
		
		//This save pixels contours of each chain in arrayList listaContornoX and Y.
		//Then, the arrays into these arrayList are passed to the Chains objects 
		//on the ImagesManipulator for extracting the contour of each chain if wanted.	
		this.setContours(drawIP,roi);
		this.polyRoi = (PolygonRoi) roi;
		
		switch (this.filterType)
		{
			case MASKS: drawFilledParticle_JChains(drawIP, roi, mask); break;
			case OUTLINES: drawOutline_JChains(drawIP, roi, rt.getCounter(),true); break;
			case ELLIPSES: drawEllipse_JChains(drawIP, stats, rt.getCounter()); break;
			case OUTLINES_WITHOUT_TEXT: drawOutline_JChains(drawIP, roi, rt.getCounter(),false); break;
			
			default:
		}
		
	}
	
	void drawFilledParticle_JChains(ImageProcessor ip, Roi roi, ImageProcessor mask) {
		//IJ.write(roi.getBounds()+" "+mask.length);
		
		ip.setRoi(roi.getBounds());
		ip.fill(mask);
		
		
		
	}


	ImageProcessor drawOutline_JChains(ImageProcessor ip, Roi roi, int count, boolean isWithText) {
		
		Rectangle r = roi.getBounds();
		
		
		int nPoints = ((PolygonRoi)roi).getNCoordinates();
		int[] xp = ((PolygonRoi)roi).getXCoordinates();
		int[] yp = ((PolygonRoi)roi).getYCoordinates();
		
		
		//int x=r.x, y=r.y;
		int x=0, y=0;
		ip.setValue(0.0);
		ip.moveTo(x+xp[0], y+yp[0]);
		for (int i=1; i<nPoints; i++)
			ip.lineTo(x+xp[i], y+yp[i]);
		
		ip.lineTo(x+xp[0], y+yp[0]);
		ip.setValue(0.0);
		
		if (isWithText)
		{
			String s = IJ.d2s(count,0);
			ip.moveTo(r.x+r.width/2-ip.getStringWidth(s)/2, r.y+r.height/2+4);
			ip.drawString(s);
		}
		
		return ip;
		
	}

	void drawEllipse_JChains(ImageProcessor ip, ImageStatistics stats, int count) {
		stats.drawEllipse(ip);
		
		
	}
	
	
	
	void setContours(ImageProcessor ip, Roi roi) 
	{
		Rectangle r = roi.getBounds();
		int nPoints = ((PolygonRoi)roi).getNCoordinates();
		int x=r.x, y=r.y;
		int[] xp = ((PolygonRoi)roi).getXCoordinates();
		int[] yp = ((PolygonRoi)roi).getYCoordinates();
		
		Integer[] intX = new Integer[nPoints];
		Integer[] intY = new Integer[nPoints];
		
		for (int i=0; i<nPoints; i++)
		{
			xp[i] = x+xp[i];
			yp[i] = y+yp[i];
			Integer integerX = new Integer(xp[i]); 
			Integer integerY = new Integer(yp[i]);
			intX[i]=integerX;
			intY[i]=integerY;
	
		}
			
		
		this.listContourX.add(count,intX);
		this.listContourY.add(count,intY);
		count++;
		
	}



	/**
	 * @return Returns the imagenFinal.
	 */
	public ImagePlus getImageFinal() {
		return imageFinal;
	}
	/**
	 * @return Returns the tituloImagenFinal.
	 */
	public String getTitleImageFinal() {
		return titleImageFinal;
	}
	/**
	 * @param tituloImagenFinal The tituloImagenFinal to set.
	 */
	public void setTitleImageFinal(String tituloImagenFinal) {
		this.titleImageFinal = tituloImagenFinal;
	}
	/**
	 * @return Returns the imageStats.
	 */
	public ImageStatistics getImageStats() {
		return imageStats;
	}
	/**
	 * @param imageStats The imageStats to set.
	 */
	public void setImageStats(ImageStatistics imageStats) {
		this.imageStats = imageStats;
	}
	/**
	 * @return Returns the roiStats.
	 */
	public Roi getRoiStats() {
		return roiStats;
	}
	/**
	 * @param roiStats The roiStats to set.
	 */
	public void setRoiStats(Roi roiStats) {
		this.roiStats = roiStats;
	}
	/**
	 * @return Returns the rt.
	 */
	public ResultsTable getRt() {
		return rt;
	}
	/**
	 * @param rt The rt to set.
	 */
	public void setRt(ResultsTable rt) {
		this.rt = rt;
	}
	/**
	 * @return Returns the listaContornosX.
	 */
	public ArrayList getListContourX() {
		return listContourX;
	}
	/**
	 * @return Returns the listaContornosY.
	 */
	public ArrayList getListContourY() {
		return listContourY;
	}
	/**
	 * @return Returns the polyRoi.
	 */
	public PolygonRoi getPolyRoi() {
		return polyRoi;
	}
}

/*
 * Created on 16-dic-2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package mains;


import interfaces.InputXML;
import interfaces.IMainInterface;

import java.io.File;

import exceptions.EmptyDirectoryException;
import exceptions.NoColloidException;

import manipulations.Directory;
import manipulations.ImagesDataComunicator;
import manipulations.ImagesManipulator;

/**
 * Main class for analysing the images. It creates
 * the directories of analysed images, data and statistics and
 * runs the corresponding objects and methods. 
 * 
 * This object can be used y a static way, using <i>main</i>
 * method, or through <i>run</i> method as a Thread.
 *
 */
public class PrincipalCommand extends Principal implements IMainInterface
{
	public PrincipalCommand ()
	{
		super();
	}
	
	public PrincipalCommand (InputXML dirXML)
	{
		
		super(dirXML);
		
	}
	
	/**
	 * Reads the parameters and runs the program.
	 *
	 */
	public void execute() 
	{
			//If the directory we need for this execution is
			//empty, a exception is throwed
			if ((dirXML.getsPath()=="") || (dirXML.getsPath()==null))
				throw new EmptyDirectoryException();
			
			this.gcComplete();
			
			ImagesDataComunicator com = new ImagesDataComunicator();
			com.setTermAfterTime(dirXML.getsSuffix());
			com.setFilterParameter(dirXML.getdFactor());
			com.setbErode(dirXML.isbErode());
			com.setbWater(dirXML.isbWater());
			
			String dir = dirXML.getsPath()+DIR_SEPARATOR;
			Directory directory = new Directory("",dir,true, dirXML.getsSuffix());
			
			ImagesManipulator man = 
				new ImagesManipulator(directory,true,com);
			
			File file = new File(dir+DIR_SEPARATOR+OUTPUT_analysed);
			file.mkdir();
			File file3 = new File(dir+DIR_SEPARATOR+OUTPUT_statistics);
			file3.mkdir();
				
			String path1 = file.getPath()+DIR_SEPARATOR;
			String path3 = file3.getPath()+DIR_SEPARATOR;
		
			man.filterAndAnalyseImages(	path1,  
										path3);
			
			//this.gcCompleto();
			System.out.println(MSG_END_PCA);
			
	
			
		}//Fin de execute
	
	/**
	 * Calls the <i>execute()</i> method
	 * @param args
	 */
	public static void main(String[] args)
	{
		try
		{
			new PrincipalCommand().execute();
		}
		catch(EmptyDirectoryException e){e.getStackTrace();}
		catch(NoColloidException e){e.getStackTrace();}
	}
	
	/**
	 * Thread <i>start()</i> calls here, then <i>run()</i> calls <i>execute()</i> method
	 */
	public void run()  
	{
		try
		{
			new PrincipalCommand().execute();
		}
		catch(EmptyDirectoryException e){e.showMessage();}
		catch(NoColloidException e){e.showMessage();}
	}
		
			

	
}

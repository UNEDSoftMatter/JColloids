package mains;


import gui.JColloidsGUI;
import interfaces.IMainInterface;
import interfaces.InputXML;


 


/**
 *  The classes contained in the <i>mains</i> package inherit from this class. 
 *  Reads the XML objects and can be used for freeing
 *  up memory.
 *
 */
public class Principal extends Thread implements IMainInterface{
	
	protected InputXML dirXML = null;
	
	
	public Principal (InputXML dirXML)
	{
		this.dirXML = dirXML;
		
	}
	
	public Principal()
	{
		this.dirXML = new InputXML();	
		
	}
	
	/**
	 * Frees up memory in the system.
	 *
	 */
	public void gcComplete()
	{
		Runtime rt = Runtime.getRuntime();
		long estaLibre = rt.freeMemory();
		
		System.out.println(MSG_FREEMEMORY_CURRENT+estaLibre);
		
		long estabaLibre;
		do
		{
			estabaLibre = estaLibre;

			System.out.println(MSG_FREEMEMORY_FREEING+estabaLibre);
			
			rt.runFinalization();
			rt.gc();
			estaLibre = rt.freeMemory();
		}while (estaLibre > estabaLibre);
	
	}

	
	public void run() {}
	
	public static void main(String args[])
	{	
		JColloidsGUI gui = new JColloidsGUI();
		gui.setVisible(true);
	}
	

	public Object construct() {
		// TODO Auto-generated method stub
		return null;
	}

	
}




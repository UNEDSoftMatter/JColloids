package manipulations;

import java.awt.geom.Point2D;
import java.util.Comparator;

/**
 * Simple object for comparing X coordinates of two Point2D objects
 *
 */
public class MyPointXSort implements Comparator 
{
	public int compare(Object o1, Object o2) 
	{
		Point2D.Double p1 = (Point2D.Double)o1;
		Point2D.Double p2 = (Point2D.Double)o2;
		double x1 = p1.x;
		double x2 = p2.x;
		if (x1 < x2) {
			return -1;
		} else if (x2 < x1) {
			return 1;
		}
		return 0;
	}
	
	public boolean equals(Object o1, Object o2) 
	{
	return compare(o1, o2) == 0;
	}
}

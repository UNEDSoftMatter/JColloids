/*
 * Created on 07-dic-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package manipulations;

import ij.io.DirectoryChooser;
import interfaces.IMainInterface;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.StringTokenizer;



/**
 * 
 * <i>Directory</i> obtains the information associated to directories.
 * When it is created it storages the objets on this directory for
 * their ulterior analysis.
 */
public class Directory implements IMainInterface
{
	private String path=Directory.DIR_EMPTY;
	private ArrayList arrayFiles;
	private String[] listFiles;
	private String mensaje="";
	private String termAfterTime = IMainInterface.XML_INPUT_suffixName;
	
	
public Directory(String mensaje)
{
	this.mensaje = mensaje;
	
}


public Directory(String mensaje, String path)
{
	this.mensaje = mensaje;
	this.path = path;
}


public Directory(String mensaje,String path, boolean esImagen, String termAfterTime)
{
	this.mensaje = mensaje;
	this.path = path;
	this.termAfterTime = termAfterTime;
	//System.out.println(termAfterTime);
	this.readsImageOrTextFiles(esImagen);
	
}

/**
 * This method indicates is Images or Text files must be read. If the argument
 * is <i>true</i> Images must be read, and Text files if it is marked as <i>false</i>.
 * @param boolean
 */
public void readsImageOrTextFiles(boolean esImagen)
{
		String directorio = this.path;
		File	ioFile			= new File(directorio);
		String[] listaArchivos = null;
		FilenameFilter fileacep;
		if (esImagen)
			fileacep = new ImageFileFilter();
		else
			fileacep = new TextFileFilter();
		
		listaArchivos = ioFile.list(fileacep);
		
		
		//This sorts the array in alphabetic order
		//by using MyFileComparator that removes possible mistakes when a
		//time number has more digits than other.
		System.out.println(MSG_READING_FILE_NAMES);
		Arrays.sort(listaArchivos, new MyFileComparator(this.termAfterTime));
		
		ArrayList  arrayArchivos = new ArrayList();
		
			
		
		if (listaArchivos!=null)
		{
			long numeroArchivos = listaArchivos.length;
			if (numeroArchivos!=0)
			{
				for (int j=0; j<listaArchivos.length; j++)
				{
					File fileTemp = new File(directorio+listaArchivos[j]);
					arrayArchivos.add(fileTemp);
					
				}
			}
		}
		
		this.path=directorio;
		this.arrayFiles=arrayArchivos;
		this.listFiles=listaArchivos;
	}
	
public void readsDirectoryChooser()
{
	DirectoryChooser dicChoos = new DirectoryChooser(mensaje); 
	String directorio	=	dicChoos.getDirectory();
	this.path = directorio;
	//leeArchivosDeImagenOTexto(esImagen);
	
}

public long extractTime(String nombreInicial, String finalNombre)
{
	String tituloOriginal = nombreInicial;
	
	StringTokenizer tituloBinaria2 = new StringTokenizer(tituloOriginal,".");
	if (tituloBinaria2.hasMoreTokens())
		tituloOriginal = tituloBinaria2.nextToken();
	
	StringTokenizer tituloBinaria3 = new StringTokenizer(tituloOriginal,finalNombre);
	if (tituloBinaria3.hasMoreTokens())
		tituloOriginal = tituloBinaria3.nextToken();
	
	//ESTO ES EL TIEMPO. UTILIZAR.
	String tiempo = tituloOriginal;
	long lTiempo = Long.parseLong(tiempo);
	
	return lTiempo; 
}


	/**
	 * @return Returns the path.
	 */
	public String getPath() {
		return path;
	}
	/**
	 * @param path The path to set.
	 */
	public void setPath(String path) {
		this.path = path;
	}
	/**
	 * @return Returns the arrayFiles.
	 */
	public ArrayList getArrayFiles() {
		return arrayFiles;
	}
	/**
	 * @return Returns the listaFiles.
	 */
	public String[] getListFiles() {
		return listFiles;
	}
}


class MyFileComparator implements Comparator, IMainInterface 
{
	private String termAfterTime = this.termAfterTime;
	
	public MyFileComparator(String termAfterTime)
	{this.termAfterTime = termAfterTime;}
	
	
	private long extraeTiempo(String nombreInicial, String finalNombre)
	{
		String tituloOriginal = nombreInicial;
		
		StringTokenizer tituloBinaria2 = new StringTokenizer(tituloOriginal,".");
		if (tituloBinaria2.hasMoreTokens())
			tituloOriginal = tituloBinaria2.nextToken();
		
		StringTokenizer tituloBinaria3 = new StringTokenizer(tituloOriginal,finalNombre);
		if (tituloBinaria3.hasMoreTokens())
			tituloOriginal = tituloBinaria3.nextToken();
	
		String tiempo = tituloOriginal;
		long lTiempo = Long.parseLong(tiempo);
		
		return lTiempo; 
	}


	public int compare(Object o1, Object o2) 
	{
		String p1 = (String)o1;
		String p2 = (String)o2;
		double l1 = extraeTiempo(p1,termAfterTime)/(double)(1000);
		double l2 = extraeTiempo(p2,termAfterTime)/(double)(1000);
		
		int p = 0;
		if (l1 < l2) {
			p=-1;
		} else if (l2 < l1) {
			p = 1;
		}
		//System.out.println("Tiempo que lee: "+l1+" y "+l2+" es "+p);
		return p;
	}
	
	public boolean equals(Object o1, Object o2) 
	{
	return compare(o1, o2) == 0;
	}



}
package manipulations;

import java.awt.geom.Point2D;
import java.util.Comparator;


/**
 * Simple object for comparing Y coordinates of two Point2D objects
 *
 */
public class MyPointYSort implements Comparator 
{
	public int compare(Object o1, Object o2) 
	{
		Point2D.Double p1 = (Point2D.Double)o1;
		Point2D.Double p2 = (Point2D.Double)o2;
		double y1 = p1.y;
		double y2 = p2.y;
		if (y1 < y2) {
			return -1;
		} else if (y2 < y1) {
			return 1;
		}
		return 0;
	}
	
	public boolean equals(Object o1, Object o2) 
	{
	return compare(o1, o2) == 0;
	}
}

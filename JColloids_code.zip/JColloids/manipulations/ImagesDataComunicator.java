/*
 * Created on 08-abr-2005
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package manipulations;

import ij.gui.Roi;
import interfaces.IMainInterface;

/**
 * This object storages the data values which are passed to ImagesManipulator
 * for the image analysis.  
 *
 */
public class ImagesDataComunicator implements IMainInterface{

	private int compressionJPG = 50;
	private double saturated = 0.5;
	private int filterMin = 0;
	private int filterMax = 255;
	private double tolerance = 0.5;
	private double minContrast = 0;
	private double maxContrast = 255;
	private String nameStatisticsDirectory = "";
	private boolean saveImagesJPG = true;
	private boolean usedRoi = false;
	private Roi roi;
	private int minSize = 30;
	private int rollingBackground = 35;
	private double filterParameter = 0.5;
	private String termAfterTime = ""; 
	private boolean bErode= true;
	private boolean bWater= true;
	
	
	public boolean isbErode() {
		return bErode;
	}
	public void setbErode(boolean bErode) {
		this.bErode = bErode;
	}
	public boolean isbWater() {
		return bWater;
	}
	public void setbWater(boolean bWater) {
		this.bWater = bWater;
	}
	public int getRollingBackground() {
		return rollingBackground;
	}
	public void setRollingBackground(int rollingFondo) {
		this.rollingBackground = rollingFondo;
	}
	public int getMinSize() {
		return minSize;
	}
	public void setMinSize(int minTamano) {
		this.minSize = minTamano;
	}
	/**
	 * @return Returns the graboImagenesJPG.
	 */
	public boolean isSaveImagesJPG() {
		return saveImagesJPG;
	}
	/**
	 * @param graboImagenesJPG The graboImagenesJPG to set.
	 */
	public void setSaveImagesJPG(boolean graboImagenesJPG) {
		this.saveImagesJPG = graboImagenesJPG;
	}
	/**
	 * @return Returns the tolerancia.
	 */
	public double getTolerance() {
		return tolerance;
	}
	/**
	 * @param tolerancia The tolerancia to set.
	 */
	public void setTolerance(double tolerancia) {
		this.tolerance = tolerancia;
	}
	/**
	 * @return Returns the filtroMax.
	 */
	public int getFilterMax() {
		return filterMax;
	}
	/**
	 * @param filtroMax The filtroMax to set.
	 */
	public void setFilterMax(int filtroMax) {
		this.filterMax = filtroMax;
	}
	/**
	 * @return Returns the filtroMin.
	 */
	public int getFilterMin() {
		return filterMin;
	}
	/**
	 * @param filtroMin The filtroMin to set.
	 */
	public void setFilterMin(int filtroMin) {
		this.filterMin = filtroMin;
	}
	/**
	 * @return Returns the saturated.
	 */
	public double getSaturated() {
		return saturated;
	}
	/**
	 * @param saturated The saturated to set.
	 */
	public void setSaturated(double saturated) {
		this.saturated = saturated;
	}
	/**
	 * @return Returns the compresionJPG.
	 */
	public int getCompressionJPG() {
		return compressionJPG;
	}
	/**
	 * @param compresionJPG The compresionJPG to set.
	 */
	public void setCompressionJPG(int compresionJPG) {
		this.compressionJPG = compresionJPG;
	}
	
	/**
	 * @return Returns the maxContrast.
	 */
	public double getMaxContrast() {
		return maxContrast;
	}
	/**
	 * @param maxContrast The maxContrast to set.
	 */
	public void setMaxContrast(double maxContrast) {
		this.maxContrast = maxContrast;
	}
	/**
	 * @return Returns the minContrast.
	 */
	public double getMinContrast() {
		return minContrast;
	}
	/**
	 * @param minContrast The minContrast to set.
	 */
	public void setMinContrast(double minContrast) {
		this.minContrast = minContrast;
	}
	/**
	 * @return Returns the nombreCarpetaEstadisticas.
	 */
	public String getNameStatisticsDirectory() {
		return nameStatisticsDirectory;
	}
	/**
	 * @param nombreCarpetaEstadisticas The nombreCarpetaEstadisticas to set.
	 */
	public void setNameStatisticsDirectory(String nombreCarpetaEstadisticas) {
		this.nameStatisticsDirectory = nombreCarpetaEstadisticas;
	}
	/**
	 * @return Returns the roi.
	 */
	public Roi getRoi() {
		return roi;
	}
	/**
	 * @param roi The roi to set.
	 */
	public void setRoi(Roi roi) {
		this.roi = roi;
	}
	/**
	 * @return Returns the utilizoRoi.
	 */
	public boolean isUsedRoi() {
		return usedRoi;
	}
	/**
	 * @param utilizoRoi The utilizoRoi to set.
	 */
	public void setUsedRoi(boolean utilizoRoi) {
		this.usedRoi = utilizoRoi;
	}
	public double getFilterParameter() {
		return filterParameter;
	}
	public void setFilterParameter(double parametroFiltro) {
		this.filterParameter = parametroFiltro;
	}
	public String getTermAfterTime() {
		return termAfterTime;
	}
	public void setTermAfterTime(String termAfterTime) {
		this.termAfterTime = termAfterTime;
	}
}


package manipulations;
import interfaces.IMainInterface;


import java.io.IOException;

import java.io.RandomAccessFile;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.StringTokenizer;



/**
 * 
 * <i>FileReaderAndWriter</i> uses the object
 * <i>RandomAccessFile</i> for a higher capacity on the reading 
 * and writing of text files. It can replace text lines indide
 * a file. Also, it can analyse text lines and extract from them
 * numerical values contained in an array of <i>Number</i>. For
 * text files writing related to chain analysis  is better to use 
 * <i>FileWriter</i>
 *
 */
public class FileReaderAndWriter implements IMainInterface   
{
	static final int FINAL_ARCHIVO = 0;
	static final int DESPUES_ULTIMA_LINEA =1;
	static final int SUSTITUIR_PROXIMA_LINEA =2;
	
	private String nombreArchivo;
	private String linea;
	private String numero;
	
	private long filepointer_antes;
	private long filepointer;
	private long final_archivo;
	
	private ArrayList tokensLinea;
	private RandomAccessFile raf;
	
	/**
	 * @param nombreArchivo
	 */
	public FileReaderAndWriter(String nombreArchivo) throws IOException
	{
		this.nombreArchivo = nombreArchivo;	
		raf = new RandomAccessFile(nombreArchivo, "rw");
		this.filepointer = raf.getFilePointer();
		this.filepointer_antes = raf.getFilePointer();
		this.final_archivo = raf.length();
		//FileChannel chan = raf.getChannel();
		
		//long fileSize = chan.size();

	    //MappedByteBuffer mapFile = chan.map(FileChannel.MapMode.READ_WRITE,0, fileSize);
	    //chan.close();
	    

		
	}
	
	   /**
     * Overwrite a sequence of bytes in a file with a replacement string.
     * The bytes which are affected start at a given offset, and are equal in
     * number to the length of the replacement string.
     * 
     * @param raFile the file to overwrite bytes in
     * @param offset the offset of the start of the bytes to overwrite
     * @param replacementString the string to overwrite the bytes with
     * @throws IOException if there's a problem accessing the file
     */
    private void overwriteString(RandomAccessFile raFile, long offset, String replacementString) throws IOException {
        raFile.seek(offset);
        raFile.write(replacementString.getBytes());
    }
    
    /**
     * Replace a sequence of contiguous bytes in a file with a replacement
     * string, which is strictly longer than the sequence of bytes.
     * 
     * <p>This is achieved by performing the following three operations:
     * 
     * <ol>
     * <li>Extend the length of the file by the excess in length.
     * <li>Starting from the end of the file and ending at the
     * offset, shift the bytes toward the end of the file by a distance equal
     * to the difference in length.
     * <li>Overwrite the replacement string at the specified offset.
     * </ol>
     * 
     * @param raFile the file within which to replace bytes 
     * @param offset the offset of the start of the bytes to replace
     * @param length the number of bytes to replace
     * @param replacementString the string to replace the bytes with, which must be longer than the number of bytes to replace
     * @param step the number of bytes we shift at a time
     * @throws IOException if there's a problem accessing the file
     */
    private void replaceWithLongerString(RandomAccessFile raFile, long offset, long length, String replacementString, final int step) throws IOException {
        long origLength = raFile.length();
        raFile.setLength(raFile.length() + replacementString.length() - length);
        long newLength = raFile.length();
                
        /*
         * Example:
         *  - raFile = "1234567890abcdefghijklmnopqrstuvwxyz"
         *  - (mOffset, mLength) = (7, 6)
         *  - replacementString = "HELLOWORLD"
         *  - STEP = 5
         * 
         * 1234567890abcdefghijklmnopqrstuvwxyz (extend length)
         * 1234567890abcdefghijklmnopqrstuvwxyz____ (copy "vwxyz")
         * 1234567890abcdefghijklmnopqrstuvwxyvwxyz (copy "qrstu")
         * 1234567890abcdefghijklmnopqrstqrstuvwxyz (copy "lmnop")
         * 1234567890abcdefghijklmnolmnopqrstuvwxyz (copy "ghijk")
         * 1234567890abcdefghijghijklmnopqrstuvwxyz (copy "def")
         * 1234567890abcdefgdefghijklmnopqrstuvwxyz (overwrite "HELLOWORLD")
         * 1234567HELLOWORLDdefghijklmnopqrstuvwxyz
         */

        int totalBytesRead = 0;
                
        while (totalBytesRead < origLength - (offset+length)) {
                    
            int bytesToRead = (int) Math.min((origLength - (offset+length)) - totalBytesRead, step);

            byte[] b = new byte[bytesToRead];
                    
            raFile.seek(origLength - totalBytesRead - bytesToRead);
            int bytesRead = raFile.read(b, 0, bytesToRead);
                    
            raFile.seek(newLength - totalBytesRead - bytesToRead);
            raFile.write(b, 0, bytesRead);
                    
            totalBytesRead += bytesRead;
        }
                    
        overwriteString(raFile, offset, replacementString);        
    }
    
    /**
     * Replace a sequence of contiguous bytes in a file with a replacement
     * string, which is strictly shorter than the sequence of bytes.
     * 
     * <p>This is achieved by performing the following three operations:
     * 
     * <ol>
     * <li>Overwrite the replacement string at the specified offset.
     * <li>Starting from the offset and ending at the end of the file,
     * shift the bytes toward the start of the file by a distance equal
     * to the difference in length.
     * <li>Truncate the length of the file by the difference in length.
     * </ol>
     * 
     * @param raFile the file within which to replace bytes 
     * @param offset the offset of the start of the bytes to replace
     * @param length the number of bytes to replace
     * @param replacementString the string to replace the bytes with, which must be shorter than the number of bytes to replace
     * @param step the number of bytes we shift at a time
     * @throws IOException if there's a problem accessing the file
     */
    private void replaceWithShorterString(RandomAccessFile raFile, long offset, long length, String replacementString, final int step) throws IOException {
        // 1. Overwrite the replacementString at mOffset 
        // 2. Copy the bytes backward, starting from mOffset
        // 3. Shorten the length of the file by the difference
        
        overwriteString(raFile, offset, replacementString);        
                    
        int totalBytesRead = 0;
                
        while (totalBytesRead < raFile.length() - (offset+length)) {
                    
            int bytesToRead = (int) Math.min(raFile.length() - (offset + length + totalBytesRead), step);

            byte[] b = new byte[bytesToRead];
                    
            raFile.seek(offset + length + totalBytesRead);
            int bytesRead = raFile.read(b, 0, bytesToRead);
                    
            raFile.seek(offset + totalBytesRead + replacementString.length());
            raFile.write(b, 0, bytesRead);
                    
            totalBytesRead += bytesRead;
        }
                
        // Now that we've shifted everything up, truncate the file
        // to the correct length 
        raFile.setLength(raFile.length() - length + replacementString.length());
    }
    

	public void writeLine(String linea,int donde)
	{
		long punteroAhora = this.filepointer;
		long longitudLinea = linea.length();
		
		try{
			
			if (donde==FileReaderAndWriter.DESPUES_ULTIMA_LINEA)
			{
				overwriteString(raf, punteroAhora, "\n"+linea);
				

			}
			else if (donde==FileReaderAndWriter.SUSTITUIR_PROXIMA_LINEA)
			{
				String lineaASustituir = this.readLine();
				long longitudLineaASustituir = lineaASustituir.length();
				long bitesASustituir = Math.abs((longitudLineaASustituir - longitudLinea));
				
				if (longitudLinea<longitudLineaASustituir)
				{
					this.replaceWithShorterString(	raf,
													punteroAhora,
													longitudLineaASustituir,
													linea,
													(int)(bitesASustituir)
													);
					
				}
				else if (longitudLinea>longitudLineaASustituir)
				{					
					this.replaceWithLongerString(	raf,
							punteroAhora,
							longitudLineaASustituir,
							linea,
							(int)(bitesASustituir)
							);
					
				}
				else
				{
					raf.writeChars(linea);
				}
			}
			else if (donde==FileReaderAndWriter.FINAL_ARCHIVO)
			{
				overwriteString(raf, this.final_archivo, "\n"+linea);
				
			}
		
			this.filepointer = raf.getFilePointer();
			this.filepointer_antes = punteroAhora;
			this.final_archivo = raf.length();
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public String readLine() //throws IOException
	{
		String linea ="";
		long filePointer =0;
		
		try {
			linea = raf.readLine();
			filePointer = raf.getFilePointer();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		this.linea = linea;
		
		this.filepointer = filePointer;
		return linea;
		
	}
	
	public ArrayList extractNumbers() 
		throws IOException, ParseException, NullPointerException
	{
			ArrayList aNumero = new ArrayList();
			int i = 0;
			String token = "";
			
			//Codigo
			StringTokenizer str = new StringTokenizer(this.linea,"\t");
			while (str.hasMoreTokens())
			{
				token = str.nextToken();
				
				if ((!token.equals("  ")) &&
						(!token.equals(" ")))
				{
					Number dToken = formatNumber(token);
					aNumero.add(dToken);
				}
	
				i++;
						
			}
					
			this.tokensLinea = aNumero;
			return aNumero;
		
	}
	
	public Number extractNumber(int numero_columna)
	{
		
		return (Number) this.tokensLinea.get(numero_columna);
	}
	
	
	public Number formatNumber(String sNumero)
	{
		
		NumberFormat nf = 
				NumberFormat.getInstance(Locale.ENGLISH);
		
		Number nb = null;
		try {
			nb = nf.parse(sNumero);
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return nb;
		//Sustituir comas por puntos!!!
	}
	
	public void clearData()
	{
		this.tokensLinea.clear();
		this.linea = "";
		this.numero = "";
	}
	
	public void close()
	{
		try {
			raf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * @return Returns the linea.
	 */
	public String getLine() {
		return linea;
	}
	
	/**
	 * @return Returns the numero.
	 */
	public String getNumber() {
		return numero;
	}

	/**
	 * @return Returns the nombreArchivo.
	 */
	public String getFileName() {
		return nombreArchivo;
	}
	/**
	 * @return Returns the tokensLinea.
	 */
	public ArrayList getTokensLine() {
		return tokensLinea;
	}
	

	/**
	 * @return Returns the filepointer.
	 */
	public long getFilepointer() {
		return filepointer;
	}
	/**
	 * @param filepointer The filepointer to set.
	 */
	public void setFilepointer(long filepointer) {
		this.filepointer = filepointer;
	}
	/**
	 * @return Returns the filepointer_antes.
	 */
	public long getFilepointer_before() {
		return filepointer_antes;
	}
	/**
	 * @param filepointer_antes The filepointer_antes to set.
	 */
	public void setFilepointer_before(long filepointer_antes) {
		this.filepointer_antes = filepointer_antes;
	}
	/**
	 * @return Returns the final_archivo.
	 */
	public long getFinal_file() {
		return final_archivo;
	}
	/**
	 * @param final_archivo The final_archivo to set.
	 */
	public void setFinal_archivo(long final_archivo) {
		this.final_archivo = final_archivo;
	}
	/**
	 * @param nombreArchivo The nombreArchivo to set.
	 */
	public void setFileName(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}
	

}

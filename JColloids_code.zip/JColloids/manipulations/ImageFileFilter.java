package manipulations;
import java.io.File;
import java.io.FilenameFilter;


/**
 * 
 * It is used for filtering the images files when a <i>File</i>
 * object it is created associated to a certain directory. So, the files 
 * contained in the directory that are not images are ignored.
 *
 */
public class ImageFileFilter implements FilenameFilter 
{
	static final String JPG = "JPG";
	static final String JPEG = "JPEG";
	static final String GIF = "GIF";
	static final String TIF = "TIF";
	static final String TIFF = "TIFF";

	public boolean accept(File dir, String name) 
	{
	    String nameUPPER = name.toUpperCase();
		boolean acepto = 	nameUPPER.endsWith("."+JPG) ||	
							nameUPPER.endsWith("."+JPEG) ||
							nameUPPER.endsWith("."+GIF) ||
							nameUPPER.endsWith("."+TIF) ||
							nameUPPER.endsWith("."+TIFF);
		return (acepto);
	 }
	
}

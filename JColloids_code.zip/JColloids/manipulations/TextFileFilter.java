/*
 * Created on 07-dic-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package manipulations;
import java.io.File;
import java.io.FilenameFilter;

/**
 * 
 * It is used for filtering the Text files when a <i>File</i>
 * object it is created associated to a certain directory. So, the files 
 * contained in the directory that are not TXT OR DAT files are ignored.
 *
 */
public class TextFileFilter implements FilenameFilter 
{
	
	static final String TXT = "TXT";
	static final String DAT = "DAT";
	
	public boolean accept(File dir, String name) 
	{
		 String nameUPPER = name.toUpperCase();
			boolean acepto = 	nameUPPER.endsWith("."+TXT) ||	
								nameUPPER.endsWith("."+DAT);
			return (acepto);
	 }
	
	
	
}

/*
 * Created on 08-dic-2004
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package manipulations;


import java.awt.*;

import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.util.*;
import java.io.*;


import tracking.Colloid;
import tracking.ColloidAnalyzer;

import com.sun.image.codec.jpeg.ImageFormatException;
import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGEncodeParam;
import com.sun.image.codec.jpeg.JPEGImageEncoder;

import exceptions.NoColloidException;
import net.sf.ij.jaiio.JAIReader;
import ij.*;
import ij.plugin.PlugIn;

import ij.plugin.filter.EDM;
import ij.plugin.filter.ParticleAnalyzer;

import ij.process.*;

import ij.gui.Roi;
import ij.io.FileSaver;
import ij.measure.*;
import interfaces.IMainInterface;



/**
 *  
 * <i>ImageManipulator</i> contains the methods for the manipulation of 
 * the images.
 */
public class ImagesManipulator implements PlugIn, Measurements, IMainInterface
{
	private Directory directory;
	
	private long storagesTime_init;
	private long storagesTime;
	private boolean isFirstImage = false;
	private ArrayList listChains_NOW;
	private ArrayList listChains_BEFORE;
	private int count = 0;
	private boolean autoFilter = false;
	private String termAfterTime = IMainInterface.XML_INPUT_suffixName; 
	
	private int minFilter = 0;
	private int maxFilter = 0;
	private boolean noThreshold = false;
	private double minContrast = 0;
	private double maxContrast = 255;
	
	private boolean bErode= true;
	private boolean bWater= true;
	
	private float particleDiameter = (float)1.0;
	private int compressionJPG = 70;
	private int minSize = 0;
	private int maxSize = 99999999;
	private boolean graboJPG = true;
	
	private boolean workingWithROI = false;
	private Roi roi;
	private double filterParameter = 1;
	
	//private boolean autoFiltro = false;
	private boolean autoContrast = false;
	
	
	ImagePlus imagenNueva = new ImagePlus();
		
	public ImagesManipulator(){}

	 
	public ImagesManipulator(Directory dic)
	{
		this.directory = dic;
		
	}
	
	public ImagesManipulator(	Directory dic,  
								ImagesDataComunicator comunicator)
	{
		this.directory = dic;
		this.compressionJPG = comunicator.getCompressionJPG();
		this.termAfterTime = comunicator.getTermAfterTime();
	}


	public ImagesManipulator(	Directory dic, 
								boolean noThreshold,
								ImagesDataComunicator comunicator)
	{
		this.directory = dic;
		this.noThreshold = noThreshold;
		this.minFilter = comunicator.getFilterMin(); 
		this.maxFilter = comunicator.getFilterMax();
		this.compressionJPG = comunicator.getCompressionJPG();
		this.minContrast = comunicator.getMinContrast();
		this.maxContrast = comunicator.getMaxContrast();
		this.graboJPG = comunicator.isSaveImagesJPG();
		this.workingWithROI = comunicator.isUsedRoi();
		this.roi = comunicator.getRoi();
		
		this.autoFilter = (this.maxFilter==0)&&(this.minFilter==0);
		this.autoContrast = (this.maxContrast==0)&&(this.minContrast==0);
		
		this.minSize = comunicator.getMinSize();
		this.filterParameter = comunicator.getFilterParameter();
		this.bErode = comunicator.isbErode();
		this.bWater = comunicator.isbWater();
		
		
		this.termAfterTime = comunicator.getTermAfterTime();
	}

	
	/**
	 * 
	 * @param int
	 * @return ImagePlus
	 */
	private ImagePlus returnFile(int numeroImagen)
	{
		ArrayList arrayFiles = directory.getArrayFiles();
		ImagePlus[] imagesJAI = null;
		try {
				imagesJAI = JAIReader.read((File)(arrayFiles).get(numeroImagen));
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		ImagePlus imagenUno = (ImagePlus)imagesJAI[0];

		return imagenUno;
	
	} 
	
	public ImagePlus giveImagePlusFromPath(String path)
	{
		ImagePlus[] imagesJAI = null;
		try {
				imagesJAI = JAIReader.read((new File(path)));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		ImagePlus imagenUno = (ImagePlus)imagesJAI[0];
		return imagenUno;
	
	} 
	
	private String changeNameToBinaries(String titulo, String finalantiguo, String finalnuevo)
	{
		String tituloOriginal = titulo;
		
		StringTokenizer tituloBinaria2 = new StringTokenizer(tituloOriginal,".");
		if (tituloBinaria2.hasMoreTokens())
			tituloOriginal = tituloBinaria2.nextToken();
		
		StringTokenizer tituloBinaria3 = new StringTokenizer(tituloOriginal,finalantiguo);
		if (tituloBinaria3.hasMoreTokens())
			tituloOriginal = tituloBinaria3.nextToken();
		
		String tiempo = tituloOriginal;
		long lTiempo = Long.parseLong(tiempo);
		this.storagesTime = lTiempo;
		
		
		return tituloOriginal+finalnuevo; 
	}


		
	private ImagePlus filterFile(ImagePlus imagen, boolean show)
	{
	
		String titulo = imagen.getTitle();
		String titulonuevo = this.changeNameToBinaries(	titulo,
														this.termAfterTime,
														OUTPUT_binaryName);	
		
		
		ImageProcessor imaproc = imagen.getProcessor();
		int auto = imaproc.getAutoThreshold();
		
		imagen.setTitle(titulonuevo);
	
		ContrastEnhancer_JColloids ce = new ContrastEnhancer_JColloids();
		ce.setNormalize(true);
		//Not showing dialog
		ce.Myrun("",imagen,false);
		
		Kuwahara_Filter_JColloids kuwa = new Kuwahara_Filter_JColloids();
		//Valor Original
		kuwa.setSize(5);
		kuwa.run(imaproc);
			
	
		imaproc.smooth();
		imaproc.findEdges();
		imaproc.invert();
		
		imagen.updateImage();
	
		if (show)
        	imagen.show();

		
		/* Convolution can be used in the following way:
		 * 
			int[] elements = { 0, -1, 0, -1, 5, -1, 0, -1,  0};
			ip.convolve3x3(elements);
		*/
				
		//long timeotsu1 = System.currentTimeMillis();
		//Let Otsu thresholding and make Autofilter as false
		OtsuThresholding_JColloids otsu = new OtsuThresholding_JColloids();
 		otsu.run(imaproc);
 		double filtro = (this.filterParameter)*(Math.abs(280-auto))+otsu.getThreshold();		
 		
 		
 		//Valor original
 		this.autoFilter = false;
 		
 		//this.autoFiltro = true;
 		this.minFilter =0;
 		this.maxFilter = (int)filtro;
 		//long timeotsu2 = System.currentTimeMillis();
		//System.out.println("Time for Otsu filtering "+(timeotsu2-timeotsu1)/(float)1000 );
		//long timecon1 = System.currentTimeMillis();
		
		ImagePlus imagen2 = new ImagePlus(imagen.getTitle(),imagen.getImage());
 	
 		ImageConverter ic2= new ImageConverter(imagen2);
		ic2.convertToGray8();
		imagen2.updateAndDraw();
		
		ImageProcessor imaproc2 = imagen2.getProcessor();
		//long timecon2 = System.currentTimeMillis();
		//System.out.println("Time for buffer and converter "+(timecon2-timecon1)/(float)1000);
		
		if (this.autoFilter)
			imaproc2.autoThreshold();
			
		else{ 
			imaproc2.setThreshold(this.minFilter,this.maxFilter,ImageProcessor.BLACK_AND_WHITE_LUT);
			imagen2.updateImage();
			}	
		
		
		
		//Needed for erode and fill holes methods
		Thresholder_JColloids bin = new Thresholder_JColloids();
 		bin.Myrun(imagen2);
 		
 		
 		
		//Valor original
 		//Usar para microreología y separación de partículas por watershed
 		BinaryFiller bfill2 = new BinaryFiller();
		bfill2.run(imagen2.getProcessor());
		
		
		//long timemy2 = System.currentTimeMillis();
		//System.out.println("Time for MyThresholder and MyBinary "+(timemy2-timemy1)/(float)1000 );
		
		//Eroding
		//Valor original
		//Usar para microreología y separación de partículas por watershed
		if (this.bErode)
			imaproc2.erode();
	
		//For Chains separation
 		//Usar para microreología y separación de partículas por watershed
		if (this.bWater)
		{
			EDM edm = new EDM();
			edm.setup("watershed", imagen2);
			edm.run(imaproc2);
		}
		 
		
		//imaproc2 = this.realizaThreshold(imaproc2);
		//this.grabarArchivoJPEG(imagen2,"D:\\",100,BufferedImage.TYPE_BYTE_BINARY);
		
		return imagen2;
	}
	
		
	
	public ImagePlus analyseImage(ImagePlus imagenPlus) throws NoColloidException
	{
				
		String titulo = imagenPlus.getTitle();
		String newtitle = this.changeNameToBinaries(		titulo,
															OUTPUT_binaryName,
															OUTPUT_analysed);	
		imagenPlus.setTitle(newtitle);
		
		ImageProcessor imaproc = imagenPlus.getProcessor();
		
		//ROI
		if (this.workingWithROI)
			imaproc.setRoi(this.roi);
		
	
		imagenPlus.setProcessor(newtitle,imaproc);
		
		 // set all PA options false
		int measurements = 	Measurements.CENTROID+
							Measurements.AREA+
							Measurements.PERIMETER+
							Measurements.FERET
							;
		int minSize = this.minSize;
		int maxSize = this.maxSize;
		
		// Initialize results table
		ResultsTable rt = new ResultsTable();
		rt.reset();
		
		// create storage for particle positions
		//int trackCount=0;
		int options = 	//ParticleAnalyzer.EXCLUDE_EDGE_PARTICLES
						//+
						ParticleAnalyzer.SHOW_OUTLINES
						//+
						//ParticleAnalyzer.FLOOD_FILL
						//+
						//ParticleAnalyzer.SHOW_NONE
						;
						
		
		//TODO: The following wastes the 60% of all time
		ColloidAnalyzer pa = 
						new ColloidAnalyzer(	options, 
											measurements, 
											rt, 
											minSize, 
											maxSize,
											imagenPlus.getTitle(),
											ColloidAnalyzer.OUTLINES_WITHOUT_TEXT
											//ChainAnalyzer.MASKS
											);

		pa.analyse(imagenPlus, imaproc);

		
		ImagePlus imagenDev = pa.getImageFinal();
			
		
		if (this.isFirstImage)
		{
			
			this.storagesTime_init = this.storagesTime;
			System.out.println(MSG_INITIAL_TIME+this.storagesTime_init);
		}
		
		long lTiempo = this.storagesTime - this.storagesTime_init;
		Long tiempo = new Long(lTiempo);
		double dTiempo = (tiempo.doubleValue()/(double)1000);
		
		
		float[] sxRes = rt.getColumn(ResultsTable.X_CENTROID);
		float[] syRes = rt.getColumn(ResultsTable.Y_CENTROID);
		float[] area = rt.getColumn(ResultsTable.AREA);
		float[] perim = rt.getColumn(ResultsTable.PERIMETER);
		//float[] feret = rt.getColumn(ResultsTable.FERET);
		String columnHeadings = rt.getColumnHeadings();
		

		
		listChains_BEFORE = new ArrayList();		
		listChains_NOW = new ArrayList();		
		
		if (sxRes==null)
			throw new NoColloidException();	
		else 
		{	
			int i=0;
			
			do
			{	
				
				
				Integer[] conX = (Integer[])pa.getListContourX().get(i);	
				Integer[] conY = (Integer[])pa.getListContourY().get(i);
				
				//TEST FOR DETECTING CHAINS CONTOUR
				/*
				for (int j =0; j<conX.length;j++)
					System.out.print("("+conX[j]+","+conY[j]+") ");
				System.out.println();
				*/
				
				//Conversion factor is 1.0 (no conversion)
				Colloid chain = new Colloid(conX, conY, 1.0);
				
				chain.setColumnHeadings(columnHeadings);
				
				float cmx = sxRes[i];
				float cmy = syRes[i];
				float fperimeter = perim[i];
				
				chain.setCMx(cmx);
				chain.setCMy(cmy);
				
				chain.setArea(area[i]);
				chain.setPerimeter(fperimeter);
				chain.putCircularity();
				chain.putNumberOfParticles();
				chain.setTime(dTiempo);
				
								
				//Add chains to the Chains List of the image
				listChains_NOW.add(chain);
			
				i++;
		
			}while (i<sxRes.length);


		}
		

		return imagenDev;
		}
	
		

	private String[] giveAnalysisReport()
	{
		String[] informe = new String[5];
		
		Calendar fecha = Calendar.getInstance();
		//WTF: Calendar.JANUARY = 0;
		informe[0] = fecha.get(Calendar.DATE) + "/" + (fecha.get(Calendar.MONTH)+1) + "/" + fecha.get(Calendar.YEAR);
		informe[1] = "--------------------------------";
		informe[2] = RPT_AUTOFILTER_PARAMETER+this.filterParameter;
		informe[3] = RPT_ERODE+this.bErode;
		informe[4] = RPT_WATERSHED+this.bWater;
	
		
		return informe;
	}

	


	public void deleteListsFromChains()
	{
		this.listChains_NOW.clear();
		this.listChains_BEFORE.clear();
		
	}
	



private String collectDataForIDL(ArrayList listaCadenas, int count)
{

	String sDatos = "";

	long  num_cadenas = listaCadenas.size();

	for (int i=0; i<num_cadenas; i++)
	{
		Colloid chain = (Colloid)listaCadenas.get(i);
		float area = chain.getArea();
		float cmx = chain.getCMx();
		float cmy = chain.getCMy();
		float circ = chain.getCircularity();
		double time = chain.getTime();
		
		sDatos = sDatos + cmx + "\t" + cmy + "\t" + time + "\t" + area + "\t" + circ + "\t" + count + "\n";
	}
		return sDatos;
}		
	


	private String giveIDLHeaders()
	{
		
		String cabeceraEstadisticas = 	ENC_CMX+"\t" +
										ENC_CMY+"\t" +
										ENC_TIME+"\t" +
										ENC_AREA+"\t" + 
										ENC_CIRC+"\t" +
										ENC_LABEL;
										
		
								
		
		return cabeceraEstadisticas;
	}

	
	
	public void writeDataOnTextFile(	String saveDirectory, 
										String nombreArchivo,
										String cabeceraEstadisticas, 
										String[] arrayStrings)
	{
	
	String formato = "."+"txt";
	String nombreArchivoGrabar = saveDirectory+nombreArchivo+formato; 
	try {
		FileWriter salida=new FileWriter(nombreArchivoGrabar);
		PrintWriter print = new PrintWriter(salida);
		for (int i=0; i<arrayStrings.length; i++)
		{
			if (i==0)
				print.println(cabeceraEstadisticas);
			print.println(arrayStrings[i]);
			
		}
		salida.close();
	
	} catch (IOException e) {e.printStackTrace();}
	
	}
	
	
    public void saveAsJpeg(	ImagePlus imp, 
    						String path, 
    						int calidad, 
    						int type)
    {
        
        int width = imp.getWidth();
        int height = imp.getHeight();
        BufferedImage   bi = new BufferedImage(width, height, type);
        try {
            FileOutputStream  f  = new FileOutputStream(path);                
            Graphics g = bi.createGraphics();
            g.drawImage(imp.getImage(), 0, 0, null);
            g.dispose();            
            JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(f);
            JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(bi);
            param.setQuality((float)(calidad/100.0), true);
            encoder.encode(bi, param);
            f.close();
        }
        catch (Exception e) {
           IJ.error("Jpeg Writer", ""+e);
        }
    }

	
	
	public void saveJPEGFile(	ImagePlus imagenPlus, 
									String saveDirectory, 
									int calidad, int type)
	{
			
			String formato = "."+"jpeg";
			String nombreArchivoGrabar = saveDirectory+imagenPlus.getTitle()+formato; 
			
			int width =  imagenPlus.getWidth();
			int height = imagenPlus.getHeight();
			if (this.workingWithROI)
			{
				Rectangle rect =  roi.getBounds();
				height = (int)rect.getHeight();
				width = (int)rect.getWidth();
			}
			BufferedImage thumbImage = new BufferedImage(	width, 
															height,
															type);
			
			BufferedOutputStream out;
			try {
				out = new BufferedOutputStream(new	FileOutputStream(nombreArchivoGrabar));
				
				
				Graphics2D graphics2D = thumbImage.createGraphics();
				graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BILINEAR);
				graphics2D.drawImage(imagenPlus.getImage(), 0, 0, imagenPlus.getWidth(),imagenPlus.getHeight(), null);
						
				JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(out);
				JPEGEncodeParam param = encoder.getDefaultJPEGEncodeParam(thumbImage);
				
				param.setQuality((float)calidad / 100.0f, false);
				encoder.setJPEGEncodeParam(param);
				encoder.encode(thumbImage);
				
				out.close();
				
				
			} 
			catch (FileNotFoundException e) {e.printStackTrace();}
			catch (ImageFormatException e) {e.printStackTrace();}
			catch (IOException e) {	e.printStackTrace();}
			

	}

	public BufferedImage saveAndExtractBufferImage(ImagePlus imagenPlus, int type)
	{
			int width =  imagenPlus.getWidth();
			int height = imagenPlus.getHeight();
			if (this.workingWithROI)
			{
				Rectangle rect =  roi.getBounds();
				height = (int)rect.getHeight();
				width = (int)rect.getWidth();
			}
			BufferedImage thumbImage = new BufferedImage(	width, 
															height,
															type);
			
			Graphics2D graphics2D = thumbImage.createGraphics();
			graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
			RenderingHints.VALUE_INTERPOLATION_BILINEAR);
			graphics2D.drawImage(imagenPlus.getImage(), 0, 0, imagenPlus.getWidth(),imagenPlus.getHeight(), null);
			
			return thumbImage;
	}
	
	
	
	public void filterImages(String path_salida) 
	{
		count=0;
		long numeroImagenes = directory.getListFiles().length;
		System.out.println(MSG_BEGIN_FILTERING);
		
		for (int i=0; i<numeroImagenes; i++)
		{
			ImagePlus imagen = this.returnFile(i);
			this.filterFile(imagen, true);
			String directorioGrabacion = path_salida+DIR_SEPARATOR;
			if (this.graboJPG)
			{
				String formato = ".gif";
				String nombreArchivoGrabar = directorioGrabacion+imagen.getTitle()+formato;
				FileSaver filesaver = new FileSaver(imagen);
				filesaver.saveAsGif(nombreArchivoGrabar);
			
			}
				
			count++;
		}
		System.out.println(MSG_END_FILTERING);

	}
	




	static double trapezoid2(double[] x, double[] y)
	{
		int N = x.length;
		double sum2 = 0;
		for (int i= 0; i<N-1; i++)
			sum2+=(x[i+1]-x[i])*((y[i]+y[i+1])/2.0);
		return sum2; 
		
	}

	static double trapezoid(double[] x, double[] y)
	{
		int N = x.length;
		double sum2 = 0;
		for (int i= 0; i<N-1; i++)
			sum2+=(x[i+1]-x[i])*(y[i+1]);
		return sum2; 
		
	}


	/**
	 * This method doesn't save binary images, only analysed.
	 */
	public void filterAndAnalyseImages(	String path_analizadas,
										String path_datos) 
	{
		
		count = 0;
		long numeroImagenes = directory.getListFiles().length;
	
		String[] stringDatos = new String[(int)numeroImagenes];
		
		System.out.println(MSG_NUMBER_FILES+numeroImagenes);
		System.out.println(MSG_BEGIN_PRINCIPAL);
		String directorioGrabacion1 = path_analizadas+DIR_SEPARATOR;
		
		
		boolean m1 = true, m2 = true,
		m3 = true, m4 = true, m5 = true, m6 = true;
		
		for (int i=0; i<numeroImagenes; i++)
		{
			if (i==0) this.isFirstImage = true;
			else this.isFirstImage = false;
			//try{
				
				//System.gc(); System.gc(); System.gc(); System.gc();
				//mem0 = Runtime.getRuntime().totalMemory() -
				//Runtime.getRuntime().freeMemory();
				
				ImagePlus imagen = this.returnFile(i);
				
				//long time2 = System.currentTimeMillis();
				
			
				if (i==0)
					imagen = this.filterFile(imagen,false);
				else
					imagen = this.filterFile(imagen,false);
				
				//long time3 = System.currentTimeMillis();
				//System.out.println("Time for filtering "+(time3-time2)/(float)1000 );


				
				//long time4 = System.currentTimeMillis();
				ImagePlus imagen3 = this.analyseImage(imagen);
				//long time5 = System.currentTimeMillis();
				//System.out.println("Tiempo for analyzing "+(time5-time4)/(float)1000 );
				
				if (this.graboJPG)
				{
					String formato = ".gif";
					String nombreArchivoGrabar = directorioGrabacion1+imagen3.getTitle()+formato;
					FileSaver filesaver = new FileSaver(imagen3);
					filesaver.saveAsGif(nombreArchivoGrabar);
							
				}
				
				
				//STATISTICS
				stringDatos[i]=collectDataForIDL(this.listChains_NOW,i);
			
				
				
			//}catch(NoChainException e2){e2.saltaMensaje();}
			count++;	
			
			//Messages of completed percent
			float completado = i*100/numeroImagenes;
			int porcentaje = 0;
			boolean muestro = false;
			if ((completado >= 9.9) && (completado <= 10.1) && m1)
				{porcentaje = 10; muestro = true; m1 = false;}
			else if ((completado >= 19.9) && (completado <= 20.1) && m2)
				{porcentaje = 20; muestro = true; m2 = false;}
			else if ((completado >= 39.9) && (completado <= 40.1) && m3)
				{porcentaje = 40; muestro = true; m3 = false;}
			else if ((completado >= 59.9) && (completado <= 60.1) && m4)
				{porcentaje = 60; muestro = true; m4 = false;}
			else if ((completado >= 79.9) && (completado <= 80.1) && m5)
				{porcentaje = 80; muestro = true; m5 = false;}
			else if ((completado >= 89.9) && (completado <= 90.1) && m6)
				{porcentaje = 90; muestro = true; m6 = false;}
			if (muestro) 
				System.out.println(MSG_COMPLETED_PERCENT + porcentaje + "%.");
				
	
			
		}//for
		
		String directorioGrabacion2 = path_datos+DIR_SEPARATOR;
		System.out.println(MSG_END_PRINCIPAL);
		//long time8 = System.currentTimeMillis();
		this.writeDataOnTextFile(	directorioGrabacion2,
									TXT_REPORT,
									TXT_REPORT,
									this.giveAnalysisReport());
		
		System.out.println(MSG_REPORT_SAVED);

		this.writeDataOnTextFile(	directorioGrabacion2,
									dataName,
									this.giveIDLHeaders(),
									stringDatos);
		


		System.out.println(MSG_STATISTICS_SAVED);
		


	}
	

	/* (non-Javadoc)
	 * @see ij.plugin.PlugIn#run(java.lang.String)
	 */
	public void run(String arg0) {}
	

	
}

